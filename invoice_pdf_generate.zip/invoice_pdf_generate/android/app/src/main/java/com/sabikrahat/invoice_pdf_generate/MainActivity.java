package com.sabikrahat.invoice_pdf_generate;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
